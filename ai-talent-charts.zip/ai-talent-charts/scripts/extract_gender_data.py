"""
extract_gender_data.py — Extracts dot-plot data from matplotlib SVGs.

Usage: python scripts/extract_gender_data.py
Reads:  input/eu_female_share_*.svg, input/workforce_vs_ai_gender_gap.svg
Writes: scripts/gender_data.json
"""
import re, json
from pathlib import Path

ROOT = Path(__file__).parent
INPUT_DIR = ROOT.parent / "input"
OUTPUT_JSON = ROOT / "gender_data.json"

YEAR_COLOURS = {
    "eu_female_tier0": {"#c6cbeb": None},          # both years same colour
    "eu_female_tier1": {"#c6cbeb": 2024, "#6c9fc6": 2025},
    "eu_female_tier2": {"#c6cbeb": 2024, "#ff7f48": 2025},
    "workforce_gap":   {"#c6cbeb": 2024, "#ff7f48": 2025},
}

GENDER_FILES = {
    "eu_female_share_tier0.svg": ("eu_female_tier0", 10),
    "eu_female_share_tier1.svg": ("eu_female_tier1", 10),
    "eu_female_share_tier2.svg": ("eu_female_tier2", 10),
    "workforce_vs_ai_gender_gap.svg": ("workforce_gap", 5),
}

SKIP_TEXT = {
    "Female share of AI talent (%)",
    "Female share gap: total workforce \u2212 AI talent (pp)",
    "Female share gap: total workforce - AI talent (pp)",
    "Source: Revelio Labs, Sept. 2025",
    "Gender gap between total workforce and AI talent: 2024 vs 2025",
}


def _get_labels(comments):
    return [
        c.strip() for c in comments
        if len(c.strip()) > 1
        and not re.match(r"^[\d\.\,\%\+\-\s]+$", c.strip())
        and c.strip() not in SKIP_TEXT
        and "Female share" not in c and "Gender gap" not in c
        and "Parity" not in c and "Source" not in c
        and "average" not in c.lower() and "EU" not in c
    ]


def _get_eu_avg(comments):
    for c in comments:
        if "EU average" in c:
            m = re.search(r"([\d\.]+)%", c)
            if m:
                return float(m.group(1))
    return None


def _get_scale(content, step):
    ticks = re.findall(
        r'<g id="xtick_(\d+)".*?<path d="M ([\d\.]+)', content, re.DOTALL
    )
    ticks = sorted((int(t[0]), float(t[1])) for t in ticks)
    px1, px2 = ticks[0][1], ticks[1][1]
    scale = step / (px2 - px1)
    origin = -scale * px1
    return scale, origin


def extract_colour_keyed(filepath, chart_key, step):
    content = filepath.read_text(encoding="utf-8")
    comments = re.findall(r"<!--\s*(.*?)\s*-->", content)

    title = next(
        (c.replace("&amp;", "&").strip() for c in comments
         if ("Female share" in c and "Tier" in c) or "Gender gap" in c),
        "",
    )
    labels = _get_labels(comments)
    eu_avg = _get_eu_avg(comments)
    scale, origin = _get_scale(content, step)
    colour_map = YEAR_COLOURS[chart_key]

    dots = re.findall(
        r'<use xlink:href="[^"]*" x="([\d\.]+)" y="([\d\.]+)" '
        r'style="fill: (#[0-9a-fA-F]{6})', content,
    )
    dots = [(float(x), float(y), c) for x, y, c in dots if float(y) > 65]

    y_groups = {}
    for x, y, col in dots:
        yk = round(y, 1)
        val = round(scale * x + origin, 1)
        year = colour_map.get(col, "unknown")
        y_groups.setdefault(yk, []).append({"val": val, "year": year})

    y_positions = sorted(y_groups.keys(), reverse=True)
    data = []
    for i, yk in enumerate(y_positions):
        if i >= len(labels):
            break
        entry = {"name": labels[i]}
        for d in y_groups[yk]:
            if d["year"] == 2024:
                entry["y2024"] = d["val"]
            elif d["year"] == 2025:
                entry["y2025"] = d["val"]
        data.append(entry)

    return {"title": title, "eu_avg": eu_avg, "data": data}


def extract_tier0(filepath, step):
    """Tier 0: both years use the same fill. Relies on SVG draw order."""
    content = filepath.read_text(encoding="utf-8")
    comments = re.findall(r"<!--\s*(.*?)\s*-->", content)

    title = next(
        (c.replace("&amp;", "&").strip() for c in comments
         if "Female share" in c and "Tier 0" in c),
        "",
    )
    labels = _get_labels(comments)
    eu_avg = _get_eu_avg(comments)
    scale, origin = _get_scale(content, step)

    all_uses = re.findall(
        r'<use xlink:href="[^"]*" x="([\d\.]+)" y="([\d\.]+)" '
        r'style="fill: #c6cbeb', content,
    )
    data_dots = [(float(x), float(y)) for x, y in all_uses if float(y) > 65]

    n = len(labels)
    group_2024 = data_dots[:n]
    group_2025 = data_dots[n:2 * n]

    unique_ys = sorted(set(d[1] for d in data_dots), reverse=True)
    y_to_label = {y: labels[i] for i, y in enumerate(unique_ys) if i < n}

    entries = {name: {} for name in labels}
    for x, y in group_2024:
        name = y_to_label.get(y)
        if name:
            entries[name]["y2024"] = round(scale * x + origin, 1)
    for x, y in group_2025:
        name = y_to_label.get(y)
        if name:
            entries[name]["y2025"] = round(scale * x + origin, 1)

    data = [{"name": name, **entries[name]} for name in labels]
    return {"title": title, "eu_avg": eu_avg, "data": data}


def main():
    all_data = {}
    for fn, (chart_key, step) in GENDER_FILES.items():
        fpath = INPUT_DIR / fn
        if not fpath.exists():
            print(f"  SKIP  {fn}")
            continue
        if chart_key == "eu_female_tier0":
            result = extract_tier0(fpath, step)
        else:
            result = extract_colour_keyed(fpath, chart_key, step)
        all_data[chart_key] = result
        print(f"  OK    {chart_key}: {len(result['data'])} entries")

    OUTPUT_JSON.write_text(json.dumps(all_data, indent=2), encoding="utf-8")
    print(f"\nWrote {OUTPUT_JSON}")


if __name__ == "__main__":
    main()
