"""
generate_gender_svg.py — Builds the interactive gender analysis SVG.

Usage: python scripts/generate_gender_svg.py
Reads:  scripts/gender_data.json
Writes: output/ai_talent_gender.svg
"""
import json
from pathlib import Path

ROOT = Path(__file__).parent
DATA_JSON = ROOT / "gender_data.json"
OUTPUT_SVG = ROOT.parent / "output" / "ai_talent_gender.svg"

# The JS for the gender chart is substantial, so we keep it in a
# multiline string. Single braces are fine here (no .format()).

JS_BODY = r"""
var COLORS_2025 = { 0: '#6c9fc6', 1: '#6c9fc6', 2: '#ff7f48' };
var state = { view: 'eu_share', tier: 0 };
var ns = 'http://www.w3.org/2000/svg';

function getDataKey() { return state.view === 'workforce' ? 'workforce_gap' : 'eu_female_tier' + state.tier; }
function updateToggle(gid, val) { var b=document.getElementById(gid).querySelectorAll('.toggle-btn'); for(var i=0;i<b.length;i++) b[i].classList.toggle('active',b[i].getAttribute('data-val')===String(val)); }
function el(tag,a) { var e=document.createElementNS(ns,tag); for(var k in a) e.setAttribute(k,a[k]); return e; }

function render() {
  var key=getDataKey(), chart=DATA[key]; if(!chart) return;
  var isShare=state.view==='eu_share', data=chart.data, eu_avg=chart.eu_avg;
  document.getElementById('chart-title').textContent=chart.title;
  document.getElementById('axis-label').textContent=isShare?'FEMALE SHARE OF AI TALENT (%)':'FEMALE SHARE GAP: TOTAL WORKFORCE \u2212 AI TALENT (PP)';
  var col2025=isShare?(COLORS_2025[state.tier]||'#6c9fc6'):'#ff7f48';
  document.getElementById('legend-dot-2025').setAttribute('fill',col2025);
  document.getElementById('tier-group').style.display=isShare?'inline-flex':'none';

  var labelW=150, chartL=labelW+10, chartR=680, chartW=chartR-chartL;
  var rowH=data.length>20?19:22, maxVal=isShare?60:30, stepVal=isShare?10:5;
  function valToPx(v) { return chartL+(v/maxVal)*chartW; }

  var area=document.getElementById('chart-area'); while(area.firstChild) area.removeChild(area.firstChild);

  for(var v=0;v<=maxVal;v+=stepVal) {
    var gx=valToPx(v);
    area.appendChild(el('line',{x1:gx,y1:-4,x2:gx,y2:data.length*rowH+4,stroke:'#e5e7eb','stroke-width':'1'}));
    var lbl=isShare?v+'%':'+'+v;
    var lt=el('text',{x:gx,y:data.length*rowH+18,'text-anchor':'middle','font-size':'10',fill:'#8b8f96'}); lt.textContent=lbl; area.appendChild(lt);
  }

  if(isShare) {
    area.appendChild(el('line',{x1:valToPx(50),y1:-4,x2:valToPx(50),y2:data.length*rowH+4,stroke:'#bfbfbf','stroke-width':'2','stroke-dasharray':'6,3',opacity:'0.7'}));
    var pt=el('text',{x:valToPx(50),y:-10,'text-anchor':'middle','font-size':'9.5',fill:'#9ca3af','font-weight':'500'}); pt.textContent='Parity (50%)'; area.appendChild(pt);
  } else {
    area.appendChild(el('line',{x1:valToPx(0),y1:-4,x2:valToPx(0),y2:data.length*rowH+4,stroke:'#bfbfbf','stroke-width':'2','stroke-dasharray':'6,3',opacity:'0.7'}));
    var gt=el('text',{x:valToPx(0)+4,y:-10,'text-anchor':'start','font-size':'9.5',fill:'#9ca3af','font-weight':'500'}); gt.textContent='Parity'; area.appendChild(gt);
  }

  if(eu_avg!=null) {
    area.appendChild(el('line',{x1:valToPx(eu_avg),y1:-4,x2:valToPx(eu_avg),y2:data.length*rowH+4,stroke:'#6c9fc6','stroke-width':'1.5','stroke-dasharray':'4,3',opacity:'0.6'}));
    var at=el('text',{x:valToPx(eu_avg),y:-10,'text-anchor':'middle','font-size':'9.5',fill:'#6c9fc6','font-weight':'500'}); at.textContent='EU avg ('+eu_avg+'%)'; area.appendChild(at);
  }

  for(var i=0;i<data.length;i++) {
    var d=data[i], cy=i*rowH+rowH/2;
    var has24=d.y2024!=null&&d.y2024!=undefined, has25=d.y2025!=null&&d.y2025!=undefined;
    var t=el('text',{x:labelW,y:cy+4,'text-anchor':'end','font-size':'12','font-weight':'500',fill:'#2a2a2a'}); t.textContent=d.name; area.appendChild(t);
    if(has24&&has25) area.appendChild(el('line',{x1:valToPx(Math.min(d.y2024,d.y2025)),y1:cy,x2:valToPx(Math.max(d.y2024,d.y2025)),y2:cy,stroke:'#d1d5db','stroke-width':'1.5','class':'connector'}));
    if(has24) area.appendChild(el('circle',{cx:valToPx(d.y2024),cy:cy,r:'5',fill:'#c6cbeb',stroke:'#202020','stroke-width':'0.5','class':'dot'}));
    if(has25) area.appendChild(el('circle',{cx:valToPx(d.y2025),cy:cy,r:'5',fill:col2025,stroke:'#202020','stroke-width':'0.5','class':'dot'}));
    if(has24&&has25) {
      var diff=d.y2025-d.y2024;
      var ac=diff>0?(isShare?'#22863a':'#cf222e'):(isShare?'#cf222e':'#22863a');
      if(Math.abs(diff)>0.5) {
        var ax=valToPx(Math.max(d.y2024,d.y2025))+14;
        var at2=el('text',{x:ax,y:cy+3.5,'font-size':'9',fill:ac,'font-weight':'600'}); at2.textContent=(diff>0?'\u25B2':'\u25BC')+Math.abs(diff).toFixed(1); area.appendChild(at2);
      }
    }
  }

  var totalH=data.length*rowH+200; var svg=document.querySelector('svg');
  svg.setAttribute('height',totalH); svg.setAttribute('viewBox','0 0 720 '+totalH);
  document.getElementById('source-line').setAttribute('y1',totalH-28); document.getElementById('source-line').setAttribute('y2',totalH-28);
  document.getElementById('source-text').setAttribute('y',totalH-12);
}

function setView(v) { state.view=v; updateToggle('view-group',v); render(); }
function setTier(t) { state.tier=t; updateToggle('tier-group',String(t)); render(); }
setTimeout(render,100);
"""


def build_svg(data_json_str):
    parts = []
    parts.append(
        '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"'
        ' width="720" height="960" viewBox="0 0 720 960">\n<defs>\n'
        '<style type="text/css">\n'
        "@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&amp;display=swap');\n"
        "* { font-family: 'Inter', system-ui, -apple-system, sans-serif; }\n"
        ".toggle-group { display: inline-flex; border-radius: 8px; border: 1px solid #d6dadd; overflow: hidden; background: #f5f6f8; }\n"
        ".toggle-btn { padding: 7px 14px; border: none; background: transparent; color: #4a4a4a; font-size: 12.5px; font-weight: 500; cursor: pointer; font-family: 'Inter', system-ui, sans-serif; white-space: nowrap; letter-spacing: 0.01em; transition: all 0.15s ease; line-height: 1.3; }\n"
        ".toggle-btn:hover:not(.active):not(:disabled) { background: #e8eaed; }\n"
        ".toggle-btn.active { background: #2a2a2a; color: #fff; font-weight: 600; }\n"
        ".toggle-btn:disabled { color: #b0b5bb; cursor: not-allowed; }\n"
        ".dot { transition: cx 0.4s cubic-bezier(0.23,1,0.32,1), opacity 0.3s ease; }\n"
        ".connector { transition: x1 0.4s cubic-bezier(0.23,1,0.32,1), x2 0.4s cubic-bezier(0.23,1,0.32,1), opacity 0.3s ease; }\n"
        "</style>\n</defs>\n\n"
    )
    parts.append(
        '<rect width="720" height="960" fill="#ffffff"/>\n'
        '<line x1="20" y1="56" x2="700" y2="56" stroke="#202020" stroke-width="2"/>\n'
        '<text x="20" y="32" font-size="20" font-weight="700" fill="#202020" letter-spacing="-0.4">AI Talent Gender Gap</text>\n'
        '<text x="20" y="50" font-size="12.5" fill="#6b7280" font-weight="400">Female share and workforce parity across countries, 2024 vs 2025</text>\n\n'
    )
    parts.append(
        '<foreignObject x="16" y="66" width="690" height="40">\n'
        '<div xmlns="http://www.w3.org/1999/xhtml" style="display:flex;gap:10px;align-items:center;padding-top:4px;">\n'
        '<div class="toggle-group" id="view-group">\n'
        """<button class="toggle-btn active" data-val="eu_share" onclick="setView('eu_share')">Female share (EU)</button>\n"""
        """<button class="toggle-btn" data-val="workforce" onclick="setView('workforce')">Workforce vs AI gap</button>\n"""
        '</div>\n'
        '<div class="toggle-group" id="tier-group">\n'
        '<button class="toggle-btn active" data-val="0" onclick="setTier(0)">Tier 0</button>\n'
        '<button class="toggle-btn" data-val="1" onclick="setTier(1)">Tier 1</button>\n'
        '<button class="toggle-btn" data-val="2" onclick="setTier(2)">Tier 2</button>\n'
        '</div>\n</div>\n</foreignObject>\n\n'
    )
    parts.append(
        '<text id="chart-title" x="20" y="128" font-size="14" font-weight="600" fill="#202020" letter-spacing="-0.14"></text>\n'
        '<text id="axis-label" x="20" y="144" font-size="10.5" fill="#8b8f96" letter-spacing="0.6" font-weight="500"></text>\n\n'
        '<g id="legend" transform="translate(520, 118)">\n'
        '<circle cx="0" cy="0" r="5" fill="#c6cbeb" stroke="#202020" stroke-width="0.5"/>\n'
        '<text x="10" y="4" font-size="11" fill="#4a4a4a">2024</text>\n'
        '<circle cx="60" cy="0" r="5" fill="#6c9fc6" stroke="#202020" stroke-width="0.5" id="legend-dot-2025"/>\n'
        '<text x="70" y="4" font-size="11" fill="#4a4a4a">2025</text>\n'
        '</g>\n\n'
        '<g id="chart-area" transform="translate(0, 160)"></g>\n\n'
        '<text id="source-text" x="700" y="948" font-size="10.5" fill="#9ca3af" text-anchor="end">'
        'Source: Revelio Labs, Sept. 2025 \u2014 analysed by Interface</text>\n'
        '<line id="source-line" x1="20" y1="932" x2="700" y2="932" stroke="#e5e7eb" stroke-width="1"/>\n\n'
    )
    parts.append(
        '<script type="text/javascript">\n// <![CDATA[\n'
        "var DATA = " + data_json_str + ";\n"
        + JS_BODY +
        "\n// ]]>\n</script>\n</svg>"
    )
    return "".join(parts)


def main():
    data = json.loads(DATA_JSON.read_text(encoding="utf-8"))
    svg = build_svg(json.dumps(data))
    OUTPUT_SVG.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_SVG.write_text(svg, encoding="utf-8")
    print(f"Wrote {OUTPUT_SVG}")


if __name__ == "__main__":
    main()
