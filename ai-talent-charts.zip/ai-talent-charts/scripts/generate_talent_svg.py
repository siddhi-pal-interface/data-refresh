"""
generate_talent_svg.py — Builds the interactive talent explorer SVG.

Usage: python scripts/generate_talent_svg.py
Reads:  scripts/talent_data.json
Writes: output/ai_talent_explorer.svg
"""
import json
from pathlib import Path

ROOT = Path(__file__).parent
DATA_JSON = ROOT / "talent_data.json"
OUTPUT_SVG = ROOT.parent / "output" / "ai_talent_explorer.svg"


def build_svg(data_json_str):
    return (
        '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"'
        ' width="720" height="920" viewBox="0 0 720 920">\n'
        "<defs>\n"
        '<style type="text/css">\n'
        "@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&amp;display=swap');\n"
        "* { font-family: 'Inter', system-ui, -apple-system, sans-serif; }\n"
        ".toggle-group { display: inline-flex; border-radius: 8px; border: 1px solid #d6dadd; overflow: hidden; background: #f5f6f8; }\n"
        ".toggle-btn { padding: 7px 14px; border: none; background: transparent; color: #4a4a4a; font-size: 12.5px; font-weight: 500; cursor: pointer; font-family: 'Inter', system-ui, sans-serif; white-space: nowrap; letter-spacing: 0.01em; transition: all 0.15s ease; line-height: 1.3; }\n"
        ".toggle-btn:hover:not(.active):not(:disabled) { background: #e8eaed; }\n"
        ".toggle-btn.active { background: #2a2a2a; color: #fff; font-weight: 600; }\n"
        ".toggle-btn:disabled { color: #b0b5bb; cursor: not-allowed; }\n"
        ".bar-rect { transition: width 0.45s cubic-bezier(0.23, 1, 0.32, 1); }\n"
        ".switch-track { display: inline-block; width: 34px; height: 18px; border-radius: 9px; background: #d6dadd; position: relative; transition: background 0.2s; cursor: pointer; flex-shrink: 0; vertical-align: middle; }\n"
        ".switch-track.on { background: #6c9fc6; }\n"
        ".switch-thumb { position: absolute; top: 2px; left: 2px; width: 14px; height: 14px; border-radius: 7px; background: #fff; transition: left 0.2s; box-shadow: 0 1px 2px rgba(0,0,0,0.15); }\n"
        ".switch-track.on .switch-thumb { left: 18px; }\n"
        ".excl-toggle { display: inline-flex; align-items: center; gap: 6px; font-size: 12px; color: #4a4a4a; cursor: pointer; user-select: none; }\n"
        "</style>\n</defs>\n\n"
        '<rect width="720" height="920" fill="#ffffff"/>\n'
        '<line x1="20" y1="56" x2="700" y2="56" stroke="#202020" stroke-width="2"/>\n'
        '<text x="20" y="32" font-size="20" font-weight="700" fill="#202020" letter-spacing="-0.4">Global AI Talent Distribution</text>\n'
        '<text x="20" y="50" font-size="12.5" fill="#6b7280" font-weight="400">Top 25 rankings across countries and metropolitan areas</text>\n\n'
        '<foreignObject x="16" y="66" width="690" height="46">\n'
        '<div xmlns="http://www.w3.org/1999/xhtml" style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;padding-top:4px;">\n'
        '<div class="toggle-group" id="geo-group">\n'
        '<button class="toggle-btn active" data-val="countries" onclick="setGeo(\'countries\')">Countries</button>\n'
        '<button class="toggle-btn" data-val="metros" onclick="setGeo(\'metros\')">Metro areas</button>\n'
        '</div>\n'
        '<div class="toggle-group" id="measure-group">\n'
        '<button class="toggle-btn active" data-val="absolute" onclick="setMeasure(\'absolute\')">Absolute</button>\n'
        '<button class="toggle-btn" data-val="percapita" onclick="setMeasure(\'percapita\')">Per capita</button>\n'
        '</div>\n'
        '<div class="toggle-group" id="tier-group">\n'
        '<button class="toggle-btn" data-val="0" onclick="setTier(0)">Tier 0</button>\n'
        '<button class="toggle-btn active" data-val="1" onclick="setTier(1)">Tier 1</button>\n'
        '<button class="toggle-btn" data-val="2" onclick="setTier(2)">Tier 2</button>\n'
        '</div>\n</div>\n</foreignObject>\n\n'
        '<foreignObject x="16" y="112" width="690" height="28">\n'
        '<div xmlns="http://www.w3.org/1999/xhtml" id="excl-container" style="display:none;text-align:right;padding-right:4px;">\n'
        '<label class="excl-toggle" onclick="toggleExcl()">\n'
        '<span class="switch-track" id="excl-track"><span class="switch-thumb"></span></span>\n'
        '<span>Excl. India &amp; US</span>\n'
        '</label>\n</div>\n</foreignObject>\n\n'
        '<text id="chart-title" x="20" y="156" font-size="14" font-weight="600" fill="#202020" letter-spacing="-0.14"></text>\n'
        '<text id="axis-label" x="20" y="172" font-size="10.5" fill="#8b8f96" letter-spacing="0.6" font-weight="500"></text>\n'
        '<g id="chart-area" transform="translate(0, 180)"></g>\n\n'
        '<text id="source-text" x="700" y="908" font-size="10.5" fill="#9ca3af" text-anchor="end">'
        'Source: Revelio Labs, Sept. 2025 \u2014 analysed by Interface</text>\n'
        '<line id="source-line" x1="20" y1="892" x2="700" y2="892" stroke="#e5e7eb" stroke-width="1"/>\n\n'
        '<script type="text/javascript">\n// <![CDATA[\n'
        "var CHART_DATA = " + data_json_str + ";\n\n"
        "var state = { geo: 'countries', measure: 'absolute', tier: 1, exclInUs: false };\n\n"
        "function getKey(g,m,t,e) { var k=g+'_'+m+'_tier'+t; if(e) k+='_excl'; return k; }\n"
        "function hasData(g,m,t,e) { return !!CHART_DATA[getKey(g,m,t,e)]; }\n"
        "function getAvailTiers(g,m) { var t=[]; for(var i=0;i<=2;i++) if(hasData(g,m,i,false)||hasData(g,m,i,true)) t.push(i); return t; }\n\n"
        "function formatVal(v,m) {\n"
        "  if(m==='percapita') return v.toFixed(2);\n"
        "  if(v>=1000) { var s=Math.round(v).toString(),r=''; for(var i=s.length-1,c=0;i>=0;i--,c++) { if(c>0&&c%3===0) r=','+r; r=s[i]+r; } return r; }\n"
        "  return v.toString();\n"
        "}\n\n"
        "function updateToggle(gid,val) { var b=document.getElementById(gid).querySelectorAll('.toggle-btn'); for(var i=0;i<b.length;i++) { if(b[i].getAttribute('data-val')===String(val)) b[i].classList.add('active'); else b[i].classList.remove('active'); } }\n\n"
        "function updateTierDisabled() {\n"
        "  var a=getAvailTiers(state.geo,state.measure);\n"
        "  var b=document.getElementById('tier-group').querySelectorAll('.toggle-btn');\n"
        "  for(var i=0;i<b.length;i++) { var t=parseInt(b[i].getAttribute('data-val')); b[i].disabled=a.indexOf(t)===-1; if(b[i].disabled) b[i].classList.remove('active'); }\n"
        "  if(a.indexOf(state.tier)===-1) { state.tier=a[0]||1; updateToggle('tier-group',state.tier); }\n"
        "}\n\n"
        "function updateExcl() {\n"
        "  var ce=hasData(state.geo,state.measure,state.tier,true), hm=hasData(state.geo,state.measure,state.tier,false);\n"
        "  var c=document.getElementById('excl-container');\n"
        "  if(ce&&hm) c.style.display='block'; else { c.style.display='none'; if(!hm&&ce) state.exclInUs=true; else state.exclInUs=false; }\n"
        "  var tk=document.getElementById('excl-track'); if(state.exclInUs) tk.classList.add('on'); else tk.classList.remove('on');\n"
        "}\n\n"
        "function render() {\n"
        "  updateTierDisabled(); updateExcl();\n"
        "  var key=getKey(state.geo,state.measure,state.tier,state.exclInUs);\n"
        "  var chart=CHART_DATA[key]; if(!chart) return;\n"
        "  document.getElementById('chart-title').textContent=chart.title;\n"
        "  document.getElementById('axis-label').textContent=state.measure==='percapita'?'PER 1,000 INHABITANTS':'AI TALENT (HEADCOUNT)';\n"
        "  var area=document.getElementById('chart-area'); while(area.firstChild) area.removeChild(area.firstChild);\n"
        "  var data=chart.data, maxVal=0, ns='http://www.w3.org/2000/svg';\n"
        "  for(var i=0;i<data.length;i++) if(data[i].value>maxVal) maxVal=data[i].value;\n"
        "  var barH=data.length>20?26:28, labelW=160, barAreaW=440, barX=labelW+8;\n"
        "  for(var i=0;i<data.length;i++) {\n"
        "    var d=data[i], y=i*barH, w=(d.value/maxVal)*barAreaW;\n"
        "    var t=document.createElementNS(ns,'text'); t.setAttribute('x',labelW); t.setAttribute('y',y+barH/2+4); t.setAttribute('text-anchor','end'); t.setAttribute('font-size','12.5'); t.setAttribute('font-weight','500'); t.setAttribute('fill','#2a2a2a'); t.textContent=d.name; area.appendChild(t);\n"
        "    var r=document.createElementNS(ns,'rect'); r.setAttribute('x',barX); r.setAttribute('y',y+3); r.setAttribute('width','0'); r.setAttribute('height',barH-8); r.setAttribute('rx','3'); r.setAttribute('fill','#6c9fc6'); r.classList.add('bar-rect'); area.appendChild(r);\n"
        "    (function(r2,tw,dl){ setTimeout(function(){ r2.setAttribute('width',tw); },dl); })(r,w,i*15+30);\n"
        "    var v=document.createElementNS(ns,'text'); v.setAttribute('x',barX+w+8); v.setAttribute('y',y+barH/2+4); v.setAttribute('text-anchor','start'); v.setAttribute('font-size','11.5'); v.setAttribute('font-weight','600'); v.setAttribute('fill','#4a4a4a'); v.textContent=formatVal(d.value,state.measure); area.appendChild(v);\n"
        "  }\n"
        "  var totalH=data.length*barH+200; var svg=document.querySelector('svg'); svg.setAttribute('height',totalH); svg.setAttribute('viewBox','0 0 720 '+totalH);\n"
        "  document.getElementById('source-line').setAttribute('y1',totalH-28); document.getElementById('source-line').setAttribute('y2',totalH-28);\n"
        "  document.getElementById('source-text').setAttribute('y',totalH-12);\n"
        "}\n\n"
        "function setGeo(v) { state.geo=v; updateToggle('geo-group',v); render(); }\n"
        "function setMeasure(v) { state.measure=v; updateToggle('measure-group',v); render(); }\n"
        "function setTier(v) { var a=getAvailTiers(state.geo,state.measure); if(a.indexOf(v)===-1) return; state.tier=v; updateToggle('tier-group',v); render(); }\n"
        "function toggleExcl() { state.exclInUs=!state.exclInUs; render(); }\n\n"
        "setTimeout(render,100);\n"
        "// ]]>\n</script>\n</svg>"
    )


def main():
    data = json.loads(DATA_JSON.read_text(encoding="utf-8"))
    svg = build_svg(json.dumps(data))
    OUTPUT_SVG.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_SVG.write_text(svg, encoding="utf-8")
    print(f"Wrote {OUTPUT_SVG}")


if __name__ == "__main__":
    main()
