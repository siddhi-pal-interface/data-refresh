"""
extract_talent_data.py — Extracts bar chart data from matplotlib SVGs.

Usage: python scripts/extract_talent_data.py
Reads:  input/top25_*.svg
Writes: scripts/talent_data.json
"""
import re, json
from pathlib import Path

ROOT = Path(__file__).parent
INPUT_DIR = ROOT.parent / "input"
OUTPUT_JSON = ROOT / "talent_data.json"

TALENT_FILES = {
    "top25_countries_absolute_tier0.svg": ("countries", "absolute", 0, False),
    "top25_countries_absolute_tier1.svg": ("countries", "absolute", 1, False),
    "top25_countries_absolute_tier2.svg": ("countries", "absolute", 2, False),
    "top25_countries_absolute_no_inus_tier2.svg": ("countries", "absolute", 2, True),
    "top25_countries_percapita_no_inus_tier0.svg": ("countries", "percapita", 0, True),
    "top25_countries_percapita_tier1.svg": ("countries", "percapita", 1, False),
    "top25_countries_percapita_tier2.svg": ("countries", "percapita", 2, False),
    "top25_metros_absolute_tier0.svg": ("metros", "absolute", 0, False),
    "top25_metros_absolute_tier1.svg": ("metros", "absolute", 1, False),
    "top25_metros_absolute_tier2.svg": ("metros", "absolute", 2, False),
    "top25_metros_percapita_tier0.svg": ("metros", "percapita", 0, False),
    "top25_metros_percapita_tier1.svg": ("metros", "percapita", 1, False),
    "top25_metros_percapita_tier2.svg": ("metros", "percapita", 2, False),
}

SKIP_LABELS = {
    "AI talent", "AI talent per 100,000 people", "Per 100,000 people",
    "AI talent per 1,000 inhabitants", "Per 1,000 inhabitants",
}


def extract_bar_data(filepath):
    content = filepath.read_text(encoding="utf-8")
    comments = re.findall(r"<!--\s*(.*?)\s*-->", content)

    title = next(
        (c.replace("&amp;", "&").strip() for c in comments if "Top 25" in c), ""
    )

    labels = [
        c.strip() for c in comments
        if len(c.strip()) > 1
        and not re.match(r"^[\d\.\,\s\-]+$", c.strip())
        and "Top" not in c and "Source" not in c
        and c.strip() not in SKIP_LABELS
    ]

    annotations = []
    for c in comments:
        c = c.strip()
        try:
            num = float(c.replace(",", ""))
            if c != "0.00":
                annotations.append(num)
        except ValueError:
            pass

    bar_values = annotations[-len(labels):]
    data = [
        {"name": labels[i], "value": bar_values[i]}
        for i in range(min(len(labels), len(bar_values)))
    ]
    data.reverse()
    return {"title": title, "data": data}


def main():
    all_data = {}
    for fn, (geo, measure, tier, excl) in TALENT_FILES.items():
        fpath = INPUT_DIR / fn
        if not fpath.exists():
            print(f"  SKIP  {fn}")
            continue
        result = extract_bar_data(fpath)
        result.update(geo=geo, measure=measure, tier=tier, excl_inus=excl)
        key = f"{geo}_{measure}_tier{tier}" + ("_excl" if excl else "")
        all_data[key] = result
        print(f"  OK    {key}: {len(result['data'])} entries")

    OUTPUT_JSON.write_text(json.dumps(all_data, indent=2), encoding="utf-8")
    print(f"\nWrote {OUTPUT_JSON}")


if __name__ == "__main__":
    main()
